import os.path
import sys
try:
    file_name = input('Please enter the name of the file you want to get data from: ')
    input_number = []
    with open(file_name) as file :
        for line in file:
            nb = line.split()
            for i in range(0, len(nb)):
                input_number.append(int(nb[i]))
    if len(input_number) < 2:
        raise ValueError
    for i in range(1, len(input_number)):
        if input_number[i] <= input_number[i - 1]:
            raise ValueError
        elif input_number[i - 1] <= 0:
            raise ValueError
except ValueError:
    print('Sorry, input file does not store valid data.')
    sys.exit()
except FileNotFoundError:
    print('Sorry, there is no such file.')
    sys.exit()
from collections import defaultdict


slope_dict=[]
slope=0
for i in range(1,len(input_number)):
	slope=input_number[i]-input_number[i-1]#the slope is difference between the consecutive number
	slope_dict.append(slope)
	i+=1

longest_ride=1
remove_num=0
count=[1]

for i in range(1,len(input_number)-1):
	if slope_dict[i-1]==slope_dict[i]:
		longest_ride=longest_ride+1
		i+=1
		count.append(longest_ride)##this place just needs the smallest value,so after longest_ride calculation,I put this value into count dictionary.About the count dictionary,it includes 
	else:
		longest_ride=1##this place i need to reset the value of the longest_ride,move i plus one
		i+=1

longest_ride1=max(count)##this place just needs the smallest value

##2
#define longest_ride_max_length;longest_ride_dict.Their initial value are all 1.Because all distances between 2 number are valid.The shortest distance is 1. 
#define difference_between_two_number and an;an=a1+nd,use the 3 loops to check
longest_ride_max_length=1
longest_ride_dict=[1]
an=0
difference_between_two_number=0

#check if an is in input_number list and smaller than the last number in this list;
#if it is True,longest_ride_max_length pluses one.whenever it is false,Deposit this value of longest_ride_max_length into longest_ride_dict and then reset ongest_ride_max_length
#when we get the value of the longest_ride_max_length;just add to one is result of number of perfect line.use the account of all the lines decrease (longest_ride_max_length+1) is remove_num--what we want to get
for i in range(0,len(input_number)):
	for j in range(i+1,len(input_number)):
		difference_between_two_number=input_number[j]-input_number[i]
		an = input_number[j] + difference_between_two_number
		while an <=input_number[-1] and an in input_number:
			longest_ride_max_length+=1
			an += difference_between_two_number
		longest_ride_dict.append(longest_ride_max_length)
		longest_ride_max_length=1

longest_ride_max_length=max(longest_ride_dict)
remove_num=len(input_number)-(longest_ride_max_length+1)

if remove_num==0:
	print('The ride is perfect!')
else:
	print('The ride could be better...')

print('The longest good ride has a length of:',longest_ride1)
print('The minimal number of pillars to remove to build a perfect ride from the rest is:',remove_num)
