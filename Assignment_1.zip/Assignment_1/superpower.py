import sys
try:
    input_number = input("Please input the heroes' powers: ").split(' ')
    input_number = [int(i) for i in input_number if i != '']
#    for i in range(0, len(input_number) - 1):
#       if input_number[i] == 0:
#            raise ValueError
except ValueError:
    print('Sorry, these are not valid power values.')
    sys.exit()

try:
    nb_of_swiches = int(input('Please input the number of power flips: '))
    if nb_of_swiches > len(input_number):
        raise ValueError
    if nb_of_swiches < 0:
        raise ValueError
except ValueError:
    print('Sorry, this is not a valid number of power flips.')
    sys.exit()

##1
nb_of_swiches1=nb_of_swiches	
M=sorted(input_number)
#print (M)
if nb_of_swiches1==0:
	print ('Possibly flipping the power of the same hero many times, the greatest achievable power is %s.' % sum(M))
else:
	for i in range(0,len(M)):
		if M[i]<0:
			M[i]=-1*M[i]
			nb_of_swiches1 -=1
			if nb_of_swiches1==0:
				break
##print 'Possibly flipping the power of the same hero many times, the greatest achievable power is'
#if nb_of_swiches==0:
#	print 'Possibly flipping the power of the same hero many times, the greatest achievable power is %s.'%sum(M)
	if nb_of_swiches1%2==0:
		print ('Possibly flipping the power of the same hero many times, the greatest achievable power is %s.' % sum(M))
	else:
		print ('Possibly flipping the power of the same hero many times, the greatest achievable power is %s.' % (sum(M)-2*min(M)))
##2
#sor all the number and transfer the number from smallest to largest multiply with -1 .if nb_of_swiches==0,break the loop;and calculate the sum of new list of N
#if not 
N=sorted(input_number)
nb_of_swiches_2 = nb_of_swiches
for i in range(0,len(N)):
	N[i]=-1*N[i]
	nb_of_swiches_2 -=1
	if nb_of_swiches_2==0:
		break
print ('Flipping the power of the same hero at most once, the greatest achievable power is %s.' % sum(N))

##3
e=0
E=[]
sum1=[]
P=input_number
nb_of_swiches_3 = nb_of_swiches
#method1:
for i in range(0,len(N)-nb_of_swiches_3+1):
	for j in range(0,nb_of_swiches_3):
		E.append(P[i+j])
	sum1.append(sum(E))
	E=[]
#method2:		
#for i in range(0,len(N)-nb_of_swiches_3+1):
#	sum1.append(sum(P[i:i+nb_of_swiches_3]))
e=sum(P)-2*min(sum1)
print ('Flipping the power of nb_of_flips many consecutive heroes, the greatest achievable power is %s.' % e)

##4
Q=input_number
F=[]
sum2=[]
f=sum(Q)    ##original sum of Q,the same as input number's
h=0
k=0

##为0时，和为sum(Q)
##为1时，和为sum(Q)-2*M(i)
##为2时，和为sum(Q)-2*(M(i)+M(i+1))
#
F.append(sum(Q))
for i in range(0,len(Q)):
	h=sum(Q)-2*Q[i]
	F.append(h)
	h=0

for i in range(0,len(Q)):
	for j in range(i+1,len(Q)):
		if j==i+1:
			k=f-2*Q[i]
			k=k-2*Q[j]
			F.append(k)
		else:
			k=k-2*Q[j]
			F.append(k)
		j +=1
	k=0
	i +=1
print ('Flipping the power of arbitrarily many consecutive heroes, the greatest achievable power is %s.' % max(F))

