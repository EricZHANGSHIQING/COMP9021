import os.path
import sys
from collections import deque

try:
    file_name = input('Please enter the name of the file you want to get data from: ')
    input_number = []
    ceiling_heights = []
    floor_heights = []
    with open(file_name) as file :
        for line in file:
            nb = line.split()
            for i in range(0, len(nb)):
                input_number.append(int(nb[i]))
    if len(input_number) < 4 or len(input_number) % 2 != 0:
        raise ValueError
    for i in range(0, len(input_number)):
        if i < len(input_number) / 2:
            ceiling_heights.append(input_number[i])
        else:
            floor_heights.append(input_number[i])
    for i in range(0,len(ceiling_heights)):
        if ceiling_heights[i] <= floor_heights[i] or ceiling_heights[i] == 0 or floor_heights[i] == 0:
            raise ValueError
except ValueError:
    print('Sorry, input file does not store valid data.')
    sys.exit()
except FileNotFoundError:
    print('Sorry, there is no such file.')
    sys.exit()
##put the floor_heights and ceiling_heights of every point into range(x,y)
##set this value transfer into the set;set(range(x,y))
##put every value of the set into distance_set_dictionary
##use the loop to compare every two points' intersection.if the length of their intersetion is over 0.That means it not empty.We can go through the tunnel.(the distance of tunnel--sum1) plus one.
#else break the loop
distance_set_dictionary=[]
b=[]
sum1=1
for i in range(0,len(ceiling_heights)):
	distance_set_dictionary.append(set(range(floor_heights[i],ceiling_heights[i])))
b=distance_set_dictionary[0]				
for i in range(1,len(ceiling_heights)-1):
	b=b.intersection(distance_set_dictionary[i])
	if len(b)>0:
		sum1 +=1
	else:
		break
print('From the west, one can into the tunnel over a distance of',sum1)
				 
##2
#we can regard every point as the starting,the same as the weastern entrance.When its intersection is not 0,sum2=sum2+1.else deposit the value into dict and then reset the value of sum2.
#use the max find maxnium of sum2 which is in dict.-- it is that one can into the tunnel over a maximum distance
sum2=1
dict=[]
distance_set_dictionary=[]
b=[]
for i in range(0,len(ceiling_heights)):
	distance_set_dictionary.append(set(range(floor_heights[i],ceiling_heights[i])))
b=distance_set_dictionary[0]
for i in range(1,len(ceiling_heights)):
	for j in range(1,len(ceiling_heights)-1):
		b=b.intersection(distance_set_dictionary[j])
		if len(b)>0:
			sum2 +=1
		else:
			break

		j+=1
		dict.append(sum2)
	sum2=1
	b=distance_set_dictionary[i]
	i+=1
print('Inside the tunnel, one can into the tunnel over a maximum distance of',max(dict))		 
