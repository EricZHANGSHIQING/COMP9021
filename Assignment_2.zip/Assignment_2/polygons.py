import os
import sys
from argparse import ArgumentParser
from re import sub
import math

sys.setrecursionlimit(10000)
class Point():
    def __init__(self, x = None, y = None, value = None):
        if x == None and y == None:
            self.x = 0
            self.y = 0
        elif x == None or y == None:
            print('Need two coordinates, point not created.')
        else:
            self.x = x
            self.y = y
        self.value = value
        self.out_direction = 0


class Polygon():
    def __init__(self):
        self.grid = []
        self.polygons = []
        self.polygon = []
 
    def explore(self, grid):        
        self.grid_lines = len(grid)
        self.grid_columns = len(grid[0])

        for x in range(self.grid_lines):
            for y in range(self.grid_columns):
                grid[x][y] = Point(x = x, y = y, value = int(grid[x][y]))
        self.grid = grid

        for i in range(self.grid_lines):
            for j in range(self.grid_columns):                
                if grid[i][j].value == 1:                    
                    self.polygon.append((i,j))
                    self.__white_mouse(i, j, 1)
                    self.polygons.append(self.polygon[1:] + [self.polygon[0]])

                    for k in range(len(self.polygon)):
                        grid[self.polygon[k][0]][self.polygon[k][1]].value = 0
                    self.polygon = []

    def __white_mouse(self, x, y, direction):

        directions = {
                      1:{
                            "desc":"right","point":(x, y + 1)
                            },
                      2:{
                            "desc":"right down","point":(x + 1, y + 1)
                            },
                      3:{
                            "desc":"down","point":(x + 1, y)
                            },
                      4:{
                            "desc":"left down","point":(x + 1, y-1)
                            },
                      5:{
                            "desc":"left","point":(x, y - 1)
                            },
                      6:{
                            "desc":"left up","point":(x - 1, y - 1)
                            },
                      7:{
                            "desc":"up","point":(x - 1, y)
                            },
                      8:{
                            "desc":"right up","point":(x - 1, y + 1)
                            },
                      }
        
        start_direction = self.__get_scanner_location(direction)            
        current = (x,y)
        current_obj = self.grid[x][y]
        
        point = directions[start_direction]["point"]
        if self.__is_valid_point(current, point):  
            point_obj = self.grid[point[0]][point[1]]
            
            if not point in self.polygon:
                self.polygon.append(current)
                current_obj.out_direction = start_direction
                self.__white_mouse(point[0], point[1], start_direction)
                                
            elif point in self.polygon and point != self.polygon[0]:
                self.polygon = self.polygon[ : self.polygon.index(point)]
                                
                circle_point = self.polygon[-1]
                circle_point_direction = self.grid[circle_point[0]][circle_point[1]].out_direction
                self.__white_mouse(circle_point[0], circle_point[1], (circle_point_direction + 3 + 8)%8 )
                                
            elif point == self.polygon[0]:
                current_obj.out_direction = start_direction
                self.polygon.append(current)
                return True
        elif direction == 8:
            self.__white_mouse(x, y, 1)
        else:
            self.__white_mouse(x, y, direction + 1)
    
    def __get_scanner_location(self, direction):
        shift = 2
        if direction == shift:
            location = 8
        else:
            location = (direction - shift + 8) % 8
        return location
    
    def __is_valid_point(self, current, point):
        x, y = current
        x_result = point[0] - x
        y_result = point[1] - y
        
        if x_result == -1:
            valid_line = x > 0
        elif x_result == 1:
            valid_line = point[0] < self.grid_lines
        else:
            valid_line = True
        
        if y_result == -1:
            valid_column = y > 0
        elif y_result == 1:
            valid_column = point[1] < self.grid_columns
        else:
            valid_column = True
        
        if valid_line and valid_column and self.grid[point[0]][point[1]].value == 1:
            return True
        else:
            #print valid_line, valid_column,self.grid[point[0]][point[1]].value,
            return False

parser = ArgumentParser()
parser.add_argument('--file', dest = 'filename', required = True)
parser.add_argument('-print', dest = 'texfile', required = False, action = 'store_true')
args = parser.parse_args()

filename = args.filename

try:
    grid = []
    with open(filename) as file:
        for line in file:
            L = []
            for c in line:
                if c == '1' or c == '0':
                    L.append(int(c))
                elif c == ' ':
                    continue
                elif c == '\n':
                    break
                else:
                    raise ValueError
            if len(L) <= 50 and len(L) >= 2:
                grid.append(L)
            elif not L:
                continue
            else:
                raise ValueError
except ValueError:
    print('Incorrect input.')
    sys.exit()
except FileNotFoundError:
    print('Can not find the file, giving up...')
    sys.exit()

all_polygons = Polygon()
try:
    all_polygons.explore(grid)
except RecursionError:
    print('Cannot get polygons as expected.')
    sys.exit()

graph = all_polygons.polygons

#In order to obtain the format of graph，where graph1[i] = [[0, 0], ... , [0, 0]].In every graph1[i],the start point is deposited twice
graph1=[]
M=[]
for i in range(len(graph)):
    for j in range(len(graph[i])):
        M.append(list(graph[i][j]))
    graph1.append(M)
    M=[]         

#in order to delete the repeated points which are not start points in the graph1

for i in range(len(graph1)):
    for j in range(len(graph1[i])-2):
        if graph1[i][j]==graph1[i][j+1]:
            del (graph1[i][j])
        elif graph1[i][j]!=graph1[i][j+1]:
            continue


# Peak_points,Peak[0]=[[0,0], ... , [0, 0]],for polys_1.txt.every Peak list the first staff is deposited twice

temporary=[]
Peak=[]
for i in range(len(graph1)):
    temporary.append([graph1[i][0][0], graph1[i][0][1]])
    record_direction = grid[graph1[i][0][0]][graph1[i][0][1]].out_direction
    for j in range(1, len(graph1[i])):
        if grid[graph1[i][j][0]][graph1[i][j][1]].out_direction != record_direction:
            temporary.append([graph1[i][j][0], graph1[i][j][1]])
            record_direction = grid[graph1[i][j][0]][graph1[i][j][1]].out_direction
    Peak.append(temporary)
    temporary = []

#calculate evey graph of Perimeter.If the point of out_direction is 1,3,5,7.perimeter_1 plus 1.
#If the point of out_direction is 2,4,6,8.perimeter_2 plus 1.
#in the end,follow the instruction of print out to return the required formar of Perimeter

def Perimeter(graph1):
    perimeter_1=0
    perimeter_2=0
    for j in range(1,len(graph1)):
        if grid[graph1[j][0]][graph1[j][1]].out_direction % 2 == 0:
            perimeter_1 += 1
        else:
            perimeter_2 += 0.4
    if perimeter_1==0:
        return (f'    Perimeter: {perimeter_2:.1f}')
    elif perimeter_2 == 0:
        return (f'    Perimeter: {perimeter_1}*sqrt(.32)')
    else:
        return (f'    Perimeter: {perimeter_2:.1f} + {perimeter_1}*sqrt(.32)')

#use the formula to calculate the area of graph       
def Compute_Area(Peak):
    Result_1 = 0
    Result_2 = 0
    for k in range(len(Peak)-1):
        Result_1 += Peak[k+1][0] * Peak[k][1]
        Result_2 += Peak[k][0] * Peak[k+1][1]
    Area = abs(Result_1 - Result_2) / 2 * 0.16
    return Area

#use the judge analysis to calculate the Nb_of_invariant_rotations.
#if the number of a polygon's Peak points is odd,return 1
#if the number of a polygon's Peak pointsis even:thre are 3 situations,1 or 2 or 4.
#if the polygon is not Central_symmetry,return 1
#if the polygon is  Central_symmetry and the number of polygon's Peak points % 4 == 0,return 4 
#if the polygon is Central_symmetry and the number of polygon's Peak points % 4 != 0,return 2 

def Nb_of_invariant_rotations(Peak):
    if (len(Peak)-1)%2!=0:
        return 1
    elif (len(Peak)-1)%2==0:
        if Central_symmetry_check(Peak)==False:
            return 1
        elif Central_symmetry_check(Peak)==True:
            if equal_side_check(Peak)==True and (len(Peak)-1)%4==0:
                return 4
            else:
                return 2
          

#To judge whether graph is in another graph or not
#because the recursion is used,that could be chhanged into the question:if the starting point of graph is in another graph
def Check_Depth(P,graph1):
    count=0
    lowerlist=[]
    upper_list=[]
    for k in range(len(graph1)-1):
        if graph1[k][0]==P[0] and graph1[k][1]<P[1]:
            lowerlist.append([graph1[k][0],graph1[k][1]])
        if graph1[k][0]==P[0]-1 and graph1[k][1]<=P[1]:
            upper_list.append([graph1[k][0],graph1[k][1]])

    for i in lowerlist:
        if graph1[graph1.index(i) - 1] in upper_list:
            count+=1
        if graph1[graph1.index(i) + 1] in upper_list:
            count+=1
    if count%2==1:
        return True
    else:
        return False
    
#To check whether the graph is Central symmetry or not.
#if number of graph's Peaks is even.To judge if the middle point of every pair of Peaks is the same one.if there is one judge that it is not the same,return false.if all middle points are same,return True. 
def Central_symmetry_check(Peak):
    n=(len(Peak)-1)//2
    for j in range(0,n-1):
        if (Peak[j][0]+Peak[j+n][0])==(Peak[j+1][0]+Peak[j+n+1][0]) and (Peak[j][1]+Peak[j+n][1])==(Peak[j+1][1]+Peak[j+n+1][1]):
            continue
        else:
            return False
    return True

#At first, use the formula z^2=(x1-x2)^2+(y1-y2)^2.
#Let z^2=N.put every N into the list side.
#If every value of N is not equal.the length is not 1.they do not equal sides.return false.
#If every value of N is equal,the length of set(side) should be 1.That means every side has the same length.return true

def equal_side_check(Peak):
    N=0
    side=[]
    for j in range(0, len(Peak)-1):
        N=(Peak[j+1][0]-Peak[j][0])**2+(Peak[j+1][1]-Peak[j][1])**2
        side.append(N)
    if len(set(side))!=1:
        return False
    else:
        return True

#reverse Peak
for i in range(len(graph1)):
       if grid[Peak[i][0][0]][Peak[i][0][1]].out_direction not in [1,2,3]: 
           Peak[i].reverse()

#use the point of out_direction.
#if the Angle between the former point of out_direction and latter point of direction is more than 180。.the covex return 'no'.otherwise return 'yes'         

def convex(Peak):
    for j in range(0,len(Peak)-1):
        if grid[Peak[j][0]][Peak[j][1]].out_direction==1:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [6,7,8]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==2:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [1,7,8]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==3:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [1,2,8]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==4:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [1,2,3]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==5:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [2,3,4]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==6:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [3,4,5]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==7:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [4,5,6]:
                return 'no'
        if grid[Peak[j][0]][Peak[j][1]].out_direction==8:
            if grid[Peak[j+1][0]][Peak[j+1][1]].out_direction in [5,6,7]:
                return 'no'
    return 'yes'

#depth_list
# obtain the depth array for every polygon,the format is that depth_list=[0,...,0]
depth=0
depth_list=[]
for i in range(len(graph1)):
    for j in range(len(graph1)):
        if i!=j:
            if Check_Depth(graph1[i][0],graph1[j])==True:
                depth+=1
    depth_list.append(depth)
    depth = 0

#define two area.set largest value of area to min_area tp find out minimum value by using the loop   
#set smallest value of area to max_area tp find out maximum value by using the loop
max_area=0
min_area=384.16

#all formats of printing txt                                          
for i in range(len(graph1)):
##    print(f'Polygon {i+1}:')
##    print(Perimeter(graph1[i]))
##    print(f'    Area: {(Compute_Area(Peak[i])):.2f}')
##    print(f'    Convex: {convex(Peak[i])}')
##    print(f'    Nb of invariant rotations: {Nb_of_invariant_rotations(Peak[i])}')
##    print(f'    Depth: {depth_list[i]}')

#use the max_area and min_area to find out the maximum area's value of graphs and the minimum area's of graphs

    if max_area <= Compute_Area(Peak[i]):
        max_area = Compute_Area(Peak[i])
    if min_area >= Compute_Area(Peak[i]):
        min_area = Compute_Area(Peak[i])
diff_area = max_area-min_area

#use the format of print out to print tex documents
if args.texfile:
    output_texfile = sub('\..*$', '', filename) + '.tex'
    with open(output_texfile, 'w') as outputTexfile:
        print('\\documentclass[10pt]{article}\n'
              '\\usepackage{tikz}\n'
              '\\usepackage[margin=0cm]{geometry}\n'
              '\\pagestyle{empty}\n'
              '\n'
              '\\begin{document}\n'
              '\n'
              '\\vspace*{\\fill}\n'
              '\\begin{center}\n'
              '\\begin{tikzpicture}[x=0.4cm, y=-0.4cm, thick, brown]', \
              file = outputTexfile
              )
        print('\\draw[ultra thick] (0, 0) -- ({}, 0) -- ({}, {}) -- (0, {}) -- cycle;'\
              .format(len(grid[0]) - 1, len(grid[0]) - 1, len(grid) - 1, len(grid) - 1), \
              file = outputTexfile)

# 100 - (area - min) / (max - min) * 100 round to obtain the color 
        for d in range(max(depth_list) + 1):
            print('%Depth {}'.format(d), file = outputTexfile)
            for i in range(len(depth_list)):
                if depth_list[i] == d:
                    if Compute_Area(Peak[i]) != max_area and Compute_Area(Peak[i]) != max_area:
                        print('\\filldraw[fill=orange!{}!yellow] ' \
                              .format(100 - round((Compute_Area(Peak[i]) - min_area) / diff_area * 100)), \
                              end = '', file = outputTexfile)
                    elif Compute_Area(Peak[i]) == max_area:
                        print('\\filldraw[fill=orange!0!yellow] ', \
                              end = '', file = outputTexfile)
                    elif Compute_Area(Peak[i]) == min_area:
                        print('\\filldraw[fill=orange!100!yellow] ', \
                              end = '', file = outputTexfile)
                    for j in range(len(Peak[i])-1):
                          print('({}, {}) -- ' \
                                .format(Peak[i][j][1], Peak[i][j][0]), \
                                end = '', file = outputTexfile)
                    print('cycle;', file = outputTexfile)
        print('\\end{tikzpicture}\n'
              '\\end{center}\n'
              '\\vspace*{\\fill}\n'
              '\n'
              '\\end{document}', \
              file = outputTexfile)    
else:
    for i in range(len(graph1)):
        print(f'Polygon {i+1}:')
        print(Perimeter(graph1[i]))
        print(f'    Area: {(Compute_Area(Peak[i])):.2f}')
        print(f'    Convex: {convex(Peak[i])}')
        print(f'    Nb of invariant rotations: {Nb_of_invariant_rotations(Peak[i])}')
        print(f'    Depth: {depth_list[i]}')
