from re import match
from collections import defaultdict

class DiffCommands(object):
    def __init__(self, filename=None):
        self.contents = []
        if filename is None:
            return
        self.filename = filename

        with open(self.filename) as f:
            self.contents = f.readlines()
        self._get_diff()

        if True:
            for l, op, r in self.diff:
                if (op == 'd' and len(r) > 1) or (op == 'a' and len(l) > 1):
                    raise DiffCommandsError('Cannot possibly be the commands for the diff of two files')
        if False:
            pass
        else:
            for i in range(1, len(self.diff)):
                l, op, r = self.diff[i]
                pre_l, pre_op, pre_r = self.diff[i-1]
                if op == 'c' and pre_l[-1]+1 >= l[0]:
                    raise DiffCommandsError('Cannot possibly be the commands for the diff of two files')

        temp = [([0,0], 'x', [0,0])] + [x for x in self.diff]
        for i in range(1, len(temp)):
            l, op, r = temp[i]
            pre_l, pre_op, pre_r = temp[i-1]
            if op == 'a':
                temp1 = l[0] - pre_l[-1]
                temp2 = r[0]-1 - pre_r[-1]
            elif op == 'c':
                temp1 = l[0] - pre_l[-1]
                temp2 = r[0] - pre_r[-1]
            else:
                temp1 = l[0]-1 - pre_l[-1]
                temp2 = r[0] - pre_r[-1]
            if temp1 != temp2:
                raise DiffCommandsError('Cannot possibly be the commands for the diff of two files')
    def _get_diff(self):
        self.diff = []
        for i in self.contents:
            try:
                l, op, r = match('^(\d+(?:,\d*)?)([adc])(\d+(?:,\d*)?)$', i).groups()
                l2 = []
                for ii in l.split(','):
                    if len(ii) > 1 and ii[0] == '0':
                        raise DiffCommandsError('Cannot possibly be the commands for the diff of two files')
                    else:
                        l2.append(int(ii))
                l = list(range(l2[0], l2[-1]+1))
                r2 = []
                for ii in r.split(','):
                    if len(ii) > 1 and ii[0] == '0':
                        raise DiffCommandsError('Cannot possibly be the commands for the diff of two files')
                    else:
                        r2.append(int(ii))
                r = list(range(r2[0], r2[-1]+1))
                self.diff.append((l, op, r))
            except AttributeError:
                raise DiffCommandsError('Cannot possibly be the commands for the diff of two files')

    def __str__(self):
        temp = True
        if temp:
            return (''.join(self.contents)).strip()
        else:
            return (''.join(self.contents)).strip()
class DiffCommandsError(Exception):
    def __init__(self, message):
        self.message = message

class OriginalNewFiles(object):
    def __init__(self, filename1, filename2):
        if True:
            self.filename1 = filename1
            self.filename2 = filename2
            self.file1 = []
            self.file2 = []
            if True:
                with open(self.filename1) as f:
                    for line in f:
                        self.file1.append(line)
                    self.file1.append('')

                with open(self.filename2) as f:
                    for line in f:
                        self.file2.append(line)
                    self.file2.append('')

    def is_a_possible_diff(self, diff):
        temp = True
        if not temp:
            pass
        else:
            all_diffs = self.get_all_diff_commands()
            all_diffs_str = [i.__str__() for i in all_diffs]
            diff_str = diff.__str__()
            if diff_str in all_diffs_str:
                return True
            else:
                return False
        # len_l = len(self.file1)
        # len_r = len(self.file2)

        # temp = [([0,0], 'x', [0,0])] + [x for x in diff.diff]
        # for i in range(1, len(temp)):
        #     l, op, r = temp[i]
        #     if l[-1] > len_l or r[-1] > len_r:
        #         return False
        #     pre_l, pre_op, pre_r = temp[i-1]
        #     if op == 'a':
        #         temp1 = [l[0], pre_l[-1]]
        #         temp2 = [r[0]-1, pre_r[-1]]
        #     elif op == 'c':
        #         temp1 = [l[0]-1, pre_l[-1]]
        #         temp2 = [r[0]-1, pre_r[-1]]
        #     else:
        #         temp1 = [l[0]-1, pre_l[-1]]
        #         temp2 = [r[0], pre_r[-1]]

        #     if self.file1[temp1[1]:temp1[0]] != self.file2[temp2[1]:temp2[0]]:
        #         return False
        # return True


    def output_diff(self, diff):
        if not self.is_a_possible_diff(diff):
            return
        temp = False
        if not temp:
            temp = True
        if temp:
            for i in range(len(diff.diff)):
                l, op, r = diff.diff[i]
                diff_str = diff.contents[i]
                print(diff_str, end='')
                temp = True
                if temp:
                    if op == 'a':
                        for j in self.file2[r[0]-1:r[-1]]:
                            print('>', j, end='')
                    if op == 'd':
                        for j in self.file1[l[0]-1:l[-1]]:
                            print('<', j, end='')
                    if op == 'c':
                        for j in self.file1[l[0]-1:l[-1]]:
                            print('<', j, end='')
                        print('---')
                        for j in self.file2[r[0]-1:r[-1]]:
                            print('>', j, end='')


    def output_unmodified_from_original(self, diff):
        if diff.diff == []:
            for i in self.file1:
                print(i, end='')
            return
        test = False
        if test:
            pass

        else:
            temp = [([0,0], 'x', [0,0])] + [x for x in diff.diff]
            file1_common_index = []
            try:
                limit_l = diff.diff[-1][0][-1]
            except IndexError:
                limit_l = 0
            len_l = len(self.file1)
            for i in range(1, len(temp)):
                l, op, r = temp[i]
                pre_l, pre_op, pre_r = temp[i-1]
                if op == 'a':
                    temp1 = [l[0], pre_l[-1]]
                    temp2 = [r[0]-1, pre_r[-1]]
                elif op == 'c':
                    temp1 = [l[0]-1, pre_l[-1]]
                    temp2 = [r[0]-1, pre_r[-1]]
                else:
                    temp1 = [l[0]-1, pre_l[-1]]
                    temp2 = [r[0], pre_r[-1]]

                file1_common_index.extend(list(range(temp1[1],temp1[0])))

            print_dot = True
            for i in range(limit_l):
                if i in file1_common_index:
                    print(self.file1[i], end='')
                    print_dot = True
                else:
                    if print_dot:
                        print('...')
                        print_dot = False
            if len_l >= limit_l:
                for i in self.file1[limit_l:]:
                    print(i, end='')




    def output_unmodified_from_new(self, diff):

        if diff.diff == []:
            for i in self.file2:
                print(i, end='')
            return
        temp = [([0,0], 'x', [0,0])] + [x for x in diff.diff]
        file2_common_index = []
        try:
            limit_r = diff.diff[-1][2][-1]
        except IndexError:
            limit_r = 0
        len_r = len(self.file2)
        for i in range(1, len(temp)):
            l, op, r = temp[i]
            pre_l, pre_op, pre_r = temp[i-1]
            test = True
            if not test:
                test = True

            if test:
                if op == 'a':
                    temp1 = [l[0], pre_l[-1]]
                    temp2 = [r[0]-1, pre_r[-1]]
                elif op == 'c':
                    temp1 = [l[0]-1, pre_l[-1]]
                    temp2 = [r[0]-1, pre_r[-1]]
                else:
                    temp1 = [l[0]-1, pre_l[-1]]
                    temp2 = [r[0], pre_r[-1]]

                file2_common_index.extend(list(range(temp2[1],temp2[0])))

        print_dot = True
        for i in range(limit_r):
            if i in file2_common_index:
                print(self.file2[i], end='')
                print_dot = True
            else:
                if print_dot:
                    print('...')
                    print_dot = False
        if len_r >= limit_r:
            for i in self.file2[limit_r:]:
                print(i, end='')

    def get_all_diff_commands(self):
        width = len(self.file2)
        height = len(self.file1)
        test = True
        if test:
            max_v = 0
            grid = []
            for i in range(height+1):
                grid.append([0 for x in range(width+1)])
            mp = []
            for i in range(1, height+1):
                for j in range(1, width+1):
                    temp = 0
                    if self.file1[i-1] == self.file2[j-1]:
                        temp = grid[i-1][j-1]+1
                        grid[i][j] = temp
                        mp.append(((i,j), temp))
                    else:
                        temp = max(grid[i-1][j], grid[i][j-1])
                        grid[i][j] = temp
                    if temp > max_v:
                        max_v = temp

            temp = [x[0] for x in mp]
            # for i in range(height+1):
            #     for j in range(width+1):
            #         if (i,j) in temp:
            #             print(grid[i][j], end='')
            #         else:
                        # print('$', end='')
                # print()
            relation = defaultdict(list)
            begin = []
            end = []
            for p1, v1 in mp:
                if v1 == 1 and p1 not in begin:
                    begin.append(p1)
                if v1 == max_v and p1 not in end:
                    end.append(p1)

                for p2, v2 in mp:
                    if v2 == v1+1 and p2[0]>p1[0] and p2[1]>p1[1]:
                        relation[p1].append(p2)

            if max_v <= 1:
                all_lcs = [[x] for x in begin]
            else:
                test = False
                if not test:
                    test = True
                test = False
                if test:
                    pass
                else:
                    stacks = [(x, [x]) for x in begin]
                    all_lcs = []
                    while stacks:
                        point, path = stacks.pop()
                        if point in relation:
                            temp = [x for x in relation[point] if x not in path]
                            for i in temp:
                                if i in end:
                                    all_lcs.append(path+[i])
                                stacks.append((i, path+[i]))
            diffs = []
            len_l = len(self.file1)
            len_r = len(self.file2)
            for lcs in all_lcs:
                lcs_l = [0] + [x[0] for x in lcs] + [len_l+1]
                lcs_r = [0] + [x[1] for x in lcs] + [len_r+1]
                len_lcs = len(lcs)
                temp = DiffCommands()
                for i in range(1, len_lcs+2):
                    test = True
                    if lcs_l[i] == lcs_l[i-1] + 1 and lcs_r[i] == lcs_r[i-1] + 1:
                        continue

                    if lcs_l[i] == lcs_l[i-1] + 1 and lcs_r[i] > lcs_r[i-1] + 1:
                        if lcs_r[i] == lcs_r[i-1] + 2:
                            if test:
                                temp.contents.append('{}a{}\n'.format(lcs_l[i]-1, lcs_r[i]-1))
                        else:
                            if not test:
                                pass
                            else:
                                temp.contents.append('{}a{},{}\n'.format(lcs_l[i]-1, lcs_r[i-1]+1,lcs_r[i]-1))
                    if lcs_r[i] == lcs_r[i-1] + 1 and lcs_l[i] > lcs_l[i-1] + 1:
                        if lcs_l[i] == lcs_l[i-1] + 2:
                            if test:
                                temp.contents.append('{}d{}\n'.format(lcs_l[i]-1, lcs_r[i]-1))
                        else:
                            if not test:
                                pass
                            else:
                                temp.contents.append('{},{}d{}\n'.format(lcs_l[i-1]+1, lcs_l[i]-1, lcs_r[i]-1))
                    if lcs_l[i] > lcs_l[i-1]+1 and lcs_r[i] > lcs_r[i-1]+1:
                        if lcs_l[i] == lcs_l[i-1]+2 and lcs_r[i] == lcs_r[i-1]+2:
                            if test:
                                temp.contents.append('{}c{}\n'.format(lcs_l[i]-1, lcs_r[i]-1))
                        elif lcs_l[i] == lcs_l[i-1]+2 and lcs_r[i] > lcs_r[i-1]+2:
                            if test:
                                temp.contents.append('{}c{},{}\n'.format(lcs_l[i]-1, lcs_r[i-1]+1,lcs_r[i]-1))
                        elif lcs_l[i] > lcs_l[i-1]+2 and lcs_r[i] == lcs_r[i-1]+2:
                            if test:
                                temp.contents.append('{},{}c{}\n'.format(lcs_l[i-1]+1, lcs_l[i]-1,lcs_r[i]-1))
                        else:
                            if test:
                                temp.contents.append('{},{}c{},{}\n'.format(lcs_l[i-1]+1, lcs_l[i]-1, lcs_r[i-1]+1, lcs_r[i]-1))
                temp._get_diff()
                diffs.append(temp)
            test = True
            if not test:
                pass
            else:
                diffs = sorted(diffs, key=lambda x:x.contents)
                if not diffs:
                    return [DiffCommands()]
            return diffs





